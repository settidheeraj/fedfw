const express = require('express')
const cors = require('cors')
const bodyParser = require('body-parser')
const fs = require('fs')
const path = require('path')

const app = express()
app.use(cors())
app.use(bodyParser.json())

const DB_FILE = path.join(__dirname, 'data.json')
function readDB(){ try { return JSON.parse(fs.readFileSync(DB_FILE)) } catch { return { courses: [] } } }
function writeDB(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)) }

// seed if empty
const db = readDB()
if(!db.courses || db.courses.length === 0){
  db.courses = [
    { id: 'c1', title: 'Intro to Security', description: 'Basics of application security' },
    { id: 'c2', title: 'React for Beginners', description: 'Build reactive UIs' },
    { id: 'c3', title: 'Node & Express', description: 'Backend fundamentals' }
  ]
  writeDB(db)
}

app.get('/api/health', (req, res) => res.json({ ok: true, time: Date.now() }))

app.get('/api/courses', (req, res) => {
  const data = readDB()
  res.json(data.courses)
})

app.post('/api/courses', (req, res) => {
  const data = readDB()
  const item = { id: 'c' + (Date.now()), ...req.body }
  data.courses.push(item)
  writeDB(data)
  res.status(201).json(item)
})

app.listen(process.env.PORT || 4000, () => console.log('Server running on port', process.env.PORT || 4000))
