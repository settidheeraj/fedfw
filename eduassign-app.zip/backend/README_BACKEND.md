Backend (Express)
-----------------
- Install: `npm install`
- Run: `npm start`
- Dev: `npm run dev` (requires nodemon)
- Default port: 4000
