import React, { createContext, useState, useContext, useEffect } from 'react'

const AppContext = createContext()

export function AppProvider({ children }){
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('edu_user')) || null
    } catch { return null }
  })
  const [token, setToken] = useState(() => localStorage.getItem('edu_token') || null)

  useEffect(() => {
    localStorage.setItem('edu_user', JSON.stringify(user))
  }, [user])

  useEffect(() => {
    if(token) localStorage.setItem('edu_token', token)
    else localStorage.removeItem('edu_token')
  }, [token])

  return <AppContext.Provider value={{ user, setUser, token, setToken }}>{children}</AppContext.Provider>
}

export const useApp = () => useContext(AppContext)
