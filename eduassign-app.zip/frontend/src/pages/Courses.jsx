import React from 'react'
import { Typography } from '@mui/material'

export default function Courses(){
  return <Typography variant='h5'>Courses page - build lists, filters, search here</Typography>
}
