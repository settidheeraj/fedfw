import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Typography, Grid, Card, CardContent, CircularProgress } from '@mui/material'

export default function Home(){
  const [courses, setCourses] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let mounted = true
    axios.get('/api/courses')
      .then(res => { if(mounted) setCourses(res.data) })
      .catch(err => { if(mounted) setError('Failed to load courses') })
      .finally(() => { if(mounted) setLoading(false) })
    return () => mounted = false
  }, [])

  if(loading) return <CircularProgress />
  if(error) return <Typography color="error">{error}</Typography>

  return (
    <>
      <Typography variant="h4" gutterBottom>Featured Courses</Typography>
      <Grid container spacing={2}>
        {courses.map(c => (
          <Grid item key={c.id} xs={12} sm={6} md={4}>
            <Card>
              <CardContent>
                <Typography variant="h6">{c.title}</Typography>
                <Typography variant="body2">{c.description}</Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </>
  )
}
