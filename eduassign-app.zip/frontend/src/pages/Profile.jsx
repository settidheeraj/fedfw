import React from 'react'
import { Typography } from '@mui/material'
import { useApp } from '../context/AppContext'

export default function Profile(){
  const { user } = useApp()
  return <div>
    <Typography variant='h5'>Profile</Typography>
    {user ? <pre>{JSON.stringify(user, null, 2)}</pre> : <Typography>Please log in</Typography>}
  </div>
}
