Frontend (Vite + React)
-----------------------
- Install: `npm install`
- Run: `npm run dev`
- Build: `npm run build`

Notes:
- Axios requests are proxied to /api (setup your proxy or run backend on same origin during development)
